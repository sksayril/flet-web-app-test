import flet as ft
import http.client
import json

def main(page: ft.Page):
    page.title = "Stock Management System"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    username = ft.TextField(label="Username", width=200)
    password = ft.TextField(label="Password", password=True, width=200)
    message = ft.Text(value="")

    def show_success_popup():
        dialog = ft.AlertDialog(
            title=ft.Text("Success"),
            content=ft.Text("Login successful!"),
            actions=[ft.ElevatedButton("OK", on_click=lambda e: navigate_to_dashboard())]
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def navigate_to_dashboard():
        page.controls.clear()

        def show_section(section_name):
            content_area.controls.clear()
            content_area.controls.append(ft.Text(f"Welcome to the {section_name} Page!", size=30))
            page.update()

        cards = [
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.icons.SHOPPING_CART, size=50, color=ft.colors.RED),
                        ft.Text("Purchase")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    alignment=ft.alignment.center,
                    padding=20,
                    on_click=lambda e: show_section("Purchase")
                )
            ),
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.icons.RECEIPT, size=50, color=ft.colors.BLUE),
                        ft.Text("Purchase Details")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    alignment=ft.alignment.center,
                    padding=20,
                    on_click=lambda e: show_section("Purchase Details")
                )
            ),
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.icons.SELL, size=50, color=ft.colors.GREEN),
                        ft.Text("Sales")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    alignment=ft.alignment.center,
                    padding=20,
                    on_click=lambda e: show_section("Sales")
                )
            ),
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.icons.LIST, size=50, color=ft.colors.ORANGE),
                        ft.Text("Sales Details")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    alignment=ft.alignment.center,
                    padding=20,
                    on_click=lambda e: show_section("Sales Details")
                )
            ),
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.icons.STORAGE, size=50, color=ft.colors.PURPLE),
                        ft.Text("Stocks")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    alignment=ft.alignment.center,
                    padding=20,
                    on_click=lambda e: show_section("Stocks")
                )
            )
        ]

        content_area = ft.Column([], expand=True)
        dashboard = ft.Row(
            controls=cards,
            alignment=ft.MainAxisAlignment.CENTER,
            wrap=True,
            spacing=10
        )

        page.add(ft.Column([dashboard, content_area]))
        page.update()

    def login_click(e):
        conn = http.client.HTTPSConnection("backend-mama-inventoryptoject-2-0.onrender.com")
        payload = json.dumps({
            "username": username.value,
            "password": password.value
        })

        headers = {
            'Content-Type': 'application/json'
        }

        try:
            conn.request("POST", "/signin", payload, headers)
            res = conn.getresponse()
            data = res.read().decode('utf-8')
            result = json.loads(data)

            if res.status == 200 and "token" in result:
                show_success_popup()
            else:
                message.value = "Login failed: " + result.get("message", "Unknown error")
        except Exception as ex:
            message.value = f"An error occurred: {str(ex)}"
        
        page.update()

    page.add(
        ft.Column(
            [
                username,
                password,
                ft.ElevatedButton("Login", on_click=login_click),
                message
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=20
        )
    )

ft.app(main)
